SELECT                                         #/******************************** VMs  ********************************/#
    vm.name as Server,
#    vm.CWx_Region as CWx_Region,
#    vm.Usage,
#    vm.Client,
#    substring_index(hd.dataCenter,'-',1) dataCenter,
 
#    s.alias,
#    s.Tier as Tier,
#	s.datacenter as Pod,
#    s.Cerner_LoB as LoB,
#    0 as replicationTarget,
    (vf.provisionedMB) / 1048576  as VMAllocatedTB
#    , 'vm' as type
    
FROM dwh_capacity.vm_dimension vm 
	JOIN 
		(select dateTk, vmtk, case virtualStorageTk when 0 then storageTk else virtualStorageTk end storageTk, provisionedMB, hostTK
			from dwh_capacity.vm_capacity_fact
		) vf ON vm.tk = vf.vmTk
        
        
	JOIN dwh_capacity.date_dimension d ON d.tk = vf.datetk AND d.latest = 1 AND vf.vmtk <> 0
	join dwh_capacity.storage_dimension s ON s.tk = vf.storageTk