SELECT                                           #/******************************** Hosts, primary only, not SVC or ONTAP ********************************/#
    h.name as Server,
--   h.CWx_Region as CWx_Region,
     h.Usage,
--   h.Client,
--   h.dataCenter as ServerDC,    
  
    s.alias as Array,
    s.tier as Tier,
--	s.datacenter as ArrayPod,
--   s.Cerner_LoB as LoB,
--   0 as replicationTarget,											#/* we assume that if it's masked and mapped, it's not a replication target */#
    (chargeback_fact.provisionedCapacityMB) / 1024 as AllocatedGB
    , 'physical' as type
    
FROM
    dwh_capacity.host_dimension h,
    dwh_capacity.chargeback_fact,
    dwh_capacity.storage_dimension s,
    dwh_capacity.date_dimension
WHERE
    date_dimension.latest = 1
        AND chargeback_fact.mappedbyVM = 0
        AND h.`tk` = chargeback_fact.hostTk
        AND `date_dimension`.`tk` = chargeback_fact.`dateTk`
		and s.tk = chargeback_fact.storageTk
--		and h.name <> 'N/A' and s.name <> 'N/A'
        and s.family <> 'SVC'
        and s.microcodeVersion  not like '%ONTAP%' and s.microcodeVersion not like '%7-Mode%'	
        and h.usage like '%ESX%' 
        
        --/* ONTAP volumes don't appear in chargeback_fact so we need to handle them separately */#
