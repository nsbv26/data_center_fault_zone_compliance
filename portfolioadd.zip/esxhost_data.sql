SELECT distinct a.vcenter
    ,a.Cluster
    ,a.FullName
    ,a.Model
    ,a.CPUModel
    ,a.MemorySize
      
      
  FROM [VMInventory].[dbo].[HostHW] a
  JOIN  [VMInventory].[dbo].[VMInv] b ON b.ESXiHost = a.FullName


  where a.Environment ='RHO'
  and a.Cluster not like '%ESXC%'
  