SELECT 
      [Cluster]
      ,[ESXiHost]
      
  FROM [VMInventory].[dbo].[VMInv]
